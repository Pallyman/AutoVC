window.AUTOVC_CONFIG = {
  API_BASE: 'https://remote-jm74.onrender.com',
  MAX_FILE_SIZE: 10 * 1024 * 1024,
  TOKEN_KEY: 'autovc_token',
  EMAIL_KEY: 'autovc_email',
  MESSAGE_AUTO_DISMISS: 5000,
  ALLOWED_FILE_TYPES: {
    'application/pdf': '📄',
    'video/mp4': '🎥',
    'audio/mpeg': '🎵',
    'audio/wav': '🎵',
    'image/jpeg': '🖼️',
    'image/png': '🖼️'
  },
  FEATURES: {
    USER_PROFILE: true
  }
};
